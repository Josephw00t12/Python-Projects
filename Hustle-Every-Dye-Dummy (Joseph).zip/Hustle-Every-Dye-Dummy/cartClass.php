<?php
require_once "dbConnector.php";
require_once "sessionConfig.php";
require_once "dbQueries.php";

class ShoppingList {

    public $shopCID;
    public $prodID;
    public $name;
    public $description;
    public $cost;
    public $image;
    public $quantity;
    public $totalCost;

    public function __construct($shopCID, $prodID, $name, $description, $cost, $image, $quantity = 1) {
        $this->shopCID = $shopCID;
        $this->prodID = $prodID;
        $this->name = $name;
        $this->cost = $cost;
        $this->image = $image;
        $this->description = $description;
        $this->quantity = $quantity;
        $this->totalCost = $cost * $quantity;
    }

    public function displayShoppingBox() {
    echo '  <li class="flex py-6">';
    echo '    <div class="h-24 w-24 flex-shrink-0 overflow-hidden rounded-md border border-gray-200">';
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mimeType = finfo_buffer($finfo, $this->image);
    finfo_close($finfo);
    echo '      <img src="data:image/' . $mimeType . ';base64,' . base64_encode($this->image) . '" alt="Product Pic" class="h-full w-full object-cover object-center">';
    echo '    </div>';
    echo '    <div class="ml-4 flex flex-1 flex-col">';
    echo '      <div>';
    echo '        <div class="flex justify-between text-base font-medium text-gray-900">';
    echo '          <h3>';
    echo '            <a href="#">' . $this->name . '</a>';
    echo '          </h3>';
    echo '          <div>';
    echo '            <p class="ml-4">Price: ₱' . $this->cost . '</p>'; // Single price
    echo '            <p class="ml-4">Total: ₱' . $this->totalCost . '</p>'; // Total price
    echo '          </div>';
    echo '        </div>';
    echo '        <p class="mt-1 text-sm text-gray-500">' . $this->description . '</p>';
    echo '      </div>';
    echo '      <div class="flex flex-1 items-end justify-between text-sm">';
    echo '        <p class="text-gray-500">Qty ' . $this->quantity . '</p>'; // Display quantity
    echo '        <div class="flex">';
    echo '         <form action="cartClass.php" method="POST">';
    echo '            <input type="hidden" name="removeEntry" value="' . $this->shopCID . '">';
    echo '            <button type="submit" class="font-medium text-indigo-600 hover:text-indigo-500">Remove</button>';
    echo '          </form>';
    echo '        </div>';
    echo '      </div>';
    echo '    </div>';
    echo '  </li>';
    }
}

if (isset($_GET['add'])) {
	
 	$prodID = $_GET['add'];
 	$productInfo = GetProducts($connect, $prodID);
 	$name = $productInfo['name'];
 	$cost = $productInfo['price'];
 	$imageData = $productInfo['image'];

 	if (!insertShoppingCart($connect, $prodID, $_SESSION['accID'], $name, $cost, $imageData)) {
    mysqli_close($connect);
      die("Query failed: " . mysqli_error($connect));
  }
  echo '<script>alert("Product added to cart!");</script>';

  header("Location: products.php");
  mysqli_close($connect);
  die();

}

if (!isset($_GET['add'])) {
  $cartArray = array();
  $resultCart = GetShoppingCart($connect, $_SESSION['accID']);
  if($resultCart) {
    foreach($resultCart as $row) {
        $cart = new ShoppingList($row['shopCID'], $row['prodID'], $row['name'], $row['description'], $row['cost'], $row['image']);
        $cartArray[] = $cart;
    }
  } else {
    echo "No data found";
  }
}

if (isset($_POST['removeEntry'])) {
  $shopCID = $_POST['removeEntry'];

  DeleteShoppingEntry($connect, $shopCID);

  header("Location: products.php");
  mysqli_close($connect);
  die();
}
?>