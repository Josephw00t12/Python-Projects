<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Comments and Reviews</title>
    <link href="src/output.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        .star {
            cursor: pointer;
        }
    </style>
</head>
<body>

<?php include 'navbar.php';?>

<?php
// testing only
$starRating = 3;
?>

<div class="container mx-auto px-4 py-8">
    <div class="mt-8">
        <h2 class="text-2xl font-bold mb-4">Comments and Reviews</h2>
        <div class="mb-4">
            <span class="text-xl mr-2" id="userRating"><?php echo $starRating; ?></span>
            <div id="stars">
                <?php
                $fullStars = floor($starRating);
                $halfStar = ($starRating - $fullStars) >= 0.5 ? true : false;
                $emptyStars = 5 - $fullStars - ($halfStar ? 1 : 0);
                for ($i = 1; $i <= 5; $i++) {
                    if ($i <= $fullStars) {
                        echo '<i class="star fas fa-star text-yellow-500" data-rating="' . $i . '"></i>';
                    } else if ($halfStar && $i == ($fullStars + 1)) {
                        echo '<i class="star fas fa-star-half-alt text-yellow-500" data-rating="' . $i . '"></i>';
                    } else {
                        echo '<i class="star far fa-star text-yellow-500" data-rating="' . $i . '"></i>';
                    }
                }
                ?>
            </div>
        </div>
        <form class="mb-4" id="reviewForm">
            <textarea class="w-full border rounded-md p-2" id="comment" placeholder="Write your comment/review here"></textarea>
            <input type="hidden" id="starRating" name="starRating">
            <button type="button" onclick="submitReview()" class="mt-2 bg-blue-500 hover:bg-blue-600 text-white rounded-md px-4 py-2">Submit</button>
        </form>
        <div>
            <div class="border border-gray-200 rounded-md p-4 mb-4">
                <h3 class="text-lg font-semibold mb-2">Human 1</h3>
                <p class="text-gray-600">"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin auctor magna non risus fermentum, a eleifend justo ultricies."</p>
                <div class="flex items-center" id="userReview">
                    <span class="text-sm mr-2">4.5</span>
                    <?php
                    $reviewStarRating = 4.5;
                    $fullStars = floor($reviewStarRating);
                    $halfStar = ($reviewStarRating - $fullStars) >= 0.5 ? true : false;
                    $emptyStars = 5 - $fullStars - ($halfStar ? 1 : 0);
                    for ($i = 0; $i < $fullStars; $i++) {
                        echo '<i class="fas fa-star text-yellow-500"></i>';
                    }
                    if ($halfStar) {
                        echo '<i class="fas fa-star-half-alt text-yellow-500"></i>';
                    }
                    for ($i = 0; $i < $emptyStars; $i++) {
                        echo '<i class="far fa-star text-yellow-500"></i>';
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php';?>

<script>
    var stars = document.querySelectorAll('.star');
    stars.forEach(function(star) {
        star.addEventListener('click', function() {
            var rating = parseInt(star.getAttribute('data-rating'));
            document.getElementById("starRating").value = rating;
            updateStars(rating);
        });
    });

    function updateStars(rating) {
        stars.forEach(function(star) {
            var starRating = parseInt(star.getAttribute('data-rating'));
            if (starRating <= rating) {
                if (star.classList.contains('far')) {
                    star.classList.remove('far');
                    star.classList.add('fas');
                } else if (star.classList.contains('fas') && star.classList.contains('fa-star-half-alt')) {
                    star.classList.remove('fas');
                    star.classList.add('far');
                }
            } else {
                if (star.classList.contains('fas') && !star.classList.contains('fa-star-half-alt')) {
                    star.classList.remove('fas');
                    star.classList.add('far');
                }
            }
        });
        document.getElementById("userRating").innerText = rating;
    }

    function submitReview() {
        var comment = document.getElementById("comment").value;
        var rating = document.getElementById("starRating").value;
        document.getElementById("userRating").innerText = rating;
    }
</script>

</body>
</html>
