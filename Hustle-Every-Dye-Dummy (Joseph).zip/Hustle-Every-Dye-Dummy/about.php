<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About</title>
  <link href="src/output.css" rel="stylesheet">
</head>
<body>
  <?php include 'navbar.php';?>
  <div class = "PARENT1">
  <section class = "ImageContainer1"><img src="pics/site_logo.png"/><h2 class="text-lg font-medium text-gray-900"> Hustle Every Dye </h2></section>
  <section class = "TextContainer1"><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Nunc sed augue lacus viverra vitae congue. Vulputate ut pharetra sit amet. Ornare arcu odio ut sem nulla pharetra diam sit amet. Pretium lectus quam id leo.</p></section>
  </div>
  <div class = "PARENT2"></div>
  <div></div>
  <div></div>
  <?php
  echo
    ''
    ;?>
  <?php include 'footer.php';?>
  
</body>
</html>