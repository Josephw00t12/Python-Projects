<?php require_once "sessionConfig.php"; 
      require_once "dbQueries.php";
      require_once "dbConnector.php";
?>
<?php
if(isset($_SESSION["accID"])) {
    $userNamePic = GetPictureUsername($connect, $_SESSION["accID"]);
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mimeType = finfo_buffer($finfo, $userNamePic['profilePic']);
    finfo_close($finfo);
    $userData = GetUserAccount($connect, $_SESSION["accID"]);

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
</head>
<body>
    <section style="background-color: #f9f9f9; font-family: 'Inter', 'sans-serif';">
        <form action="sign_upLogic.php" method="POST" enctype="multipart/form-data">
            <div style="max-width: 400px; margin: 0 auto; padding: 20px; border-radius: 5px; background-color: #ffffff; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
                <div style="display: flex; align-items: center;">
                    <img src="data:image/<?php echo $mimeType; ?>;base64, <?php echo base64_encode($userNamePic['profilePic']); ?>" alt="User Photo" style="width: 150px; height: 150px; border-radius: 50%; margin-bottom: 20px;">
                    <p style="margin-left: 30px; font-size: 18px;">Hello <span id="usernameDisplay"> <?php echo $userNamePic['userName']; ?> </span>!</p>
                </div>
                <br>
                <?php
                if(isset($_SESSION["errorsSignup"])) {
                    $errors = $_SESSION["errorsSignup"];
                    foreach($errors as $error) {
                        echo '<span class="">' . $error . '</span>';
                    }
                    unset($_SESSION["errorsSignup"]);
                }
                if(isset($_SESSION["successEdit"])) {
                    echo '<span class="">' . $_SESSION['successEdit'] . '</span>';
                    unset($_SESSION["successEdit"]);
                }
                ?>
                <br>
                <label for="username" style="font-size: 14px; font-weight: 500; color: #333;">Username:</label>
                <input type="text" id="username" name="userName" value="<?php echo $userNamePic['userName'];?>" style="width: 95%; padding: 10px; margin-bottom: 15px; border: 1px solid #ccc; border-radius: 5px; font-size: 14px; color: #333;">
                <br><br>
                <div style="display: flex; justify-content: space-between;">
                    <div style="width: 48%;">
                        <label for="firstName" style="font-size: 14px; font-weight: 500; color: #333;">First Name:</label>
                        <input type="text" id="firstName" name="firstName" value="<?php echo $userData['firstName'];?>" style="width: calc(100% - 24px); padding: 10px; margin-bottom: 15px; border: 1px solid #ccc; border-radius: 5px; font-size: 14px; color: #333;">
                    </div>
                    <div style="width: 48%;">
                        <label for="lastName" style="font-size: 14px; font-weight: 500; color: #333;">Last Name:</label>
                        <input type="text" name="lastName" id="lastName" value="<?php echo $userData['lastName'];?>" style="width: calc(100% - 24px); padding: 10px; margin-bottom: 15px; border: 1px solid #ccc; border-radius: 5px; font-size: 14px; color: #333;">
                    </div>
                </div>
                <label for="email" style="font-size: 14px; font-weight: 500; color: #333;">Email:</label>
                <input type="email" id="email" name="email" value="<?php echo $userData['email'];?>" style="width: 95%; padding: 10px; margin-bottom: 15px; border: 1px solid #ccc; border-radius: 5px; font-size: 14px; color: #333;">
                <br><br>
                <label for="password" style="font-size: 14px; font-weight: 500; color: #333;">Password:</label>
                <input type="password" id="password" name="password" value="<?php echo $userData['password'];?>" style="width: 95%; padding: 10px; margin-bottom: 15px; border: 1px solid #ccc; border-radius: 5px; font-size: 14px; color: #333;">
                <br><br>
                <label for="mobile" style="font-size: 14px; font-weight: 500; color: #333;">Mobile Number:</label>
                <input type="text" id="mobile" name="mobileNumber" value="<?php echo $userData['mobileNumber'];?>" style="width: 95%; padding: 10px; margin-bottom: 15px; border: 1px solid #ccc; border-radius: 5px; font-size: 14px; color: #333;">
                <br><br>
                <label for="image" style="font-size: 14px; font-weight: 500; color: #333;">Image:</label>
                <input type="file" id="image" name="image" style="width: 95%; padding: 10px; margin-bottom: 15px; border: 1px solid #ccc; border-radius: 5px; font-size: 14px; color: #333;">
                <br><br>
                <div style="display: flex; justify-content: space-between;">
                    <button type="submit" name="submitDelete" onclick="return confirm('Are you sure you want to delete your account? This action cannot be undone.');" style="padding: 10px 20px; margin: 0 5px; border: none; border-radius: 5px; cursor: pointer; background-color: #dc3545; color: #fff;">Delete Account</button>
                    <button type="submit" name="submitEdit" style="padding: 10px 20px; margin: 0 5px; border: none; border-radius: 5px; cursor: pointer; background-color: #007bff; color: #fff;">Edit Account</button>
                    <button type="submit" name="submitExit" style="padding: 10px 20px; margin: 0 5px; border: none; border-radius: 5px; cursor: pointer; background-color: #007bff; color: #fff;">Exit</button>
                </div>
            </div>
        </form>
    </section>

    <script>
        function exit() {
            // Code to handle saving account details
            alert("Saving account...");
        }
    </script>
</body>
</html>
