<?php
require_once "dbConnector.php";
require_once "sessionConfig.php";
require_once "dbQueries.php";
require_once "navbar.php";
require_once "cartClass.php" ?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Index</title>
<link href="src/output.css" rel="stylesheet">
</head>
<body>

<?php echo '
  <div id="shoppingCartSidebar" class="relative z-10" aria-labelledby="slide-over-title" role="dialog" aria-modal="true">
  <!--
    Background backdrop, show/hide based on slide-over state.

    Entering: "ease-in-out duration-500"
      From: "opacity-0"
      To: "opacity-100"
    Leaving: "ease-in-out duration-500"
      From: "opacity-100"
      To: "opacity-0"
  -->
  <div class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity"></div>

  <div class="fixed inset-0 overflow-hidden">
    <div class="absolute inset-0 overflow-hidden">
      <div class="pointer-events-none fixed inset-y-0 right-0 flex max-w-full pl-10">
        <!--
          Slide-over panel, show/hide based on slide-over state.

          Entering: "transform transition ease-in-out duration-500 sm:duration-700"
            From: "translate-x-full"
            To: "translate-x-0"
          Leaving: "transform transition ease-in-out duration-500 sm:duration-700"
            From: "translate-x-0"
            To: "translate-x-full"
        -->
        <div class="pointer-events-auto w-screen max-w-md">
          <div class="flex h-full flex-col overflow-y-scroll bg-white shadow-xl">
            <div class="flex-1 overflow-y-auto px-4 py-6 sm:px-6">
              <div class="flex items-start justify-between">
                <h2 class="text-lg font-medium text-gray-900" id="slide-over-title">Shopping cart</h2>
                <div class="ml-3 flex h-7 items-center">
                  <button type="button" class="relative -m-2 p-2 text-gray-400 hover:text-gray-500" onclick="toggleShoppingCart()">
                      <span class="absolute -inset-0.5"></span>
                      <span class="sr-only">Close panel</span>
                      <svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true">
                          <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" />
                      </svg>
                  </button>
                </div>
              </div>

              <div class="mt-8">
                <div class="flow-root">
                  <ul role="list" class="-my-6 divide-y divide-gray-200">';
                      $updatedCartArray = array();
                      foreach ($cartArray as $cart) {
                          $existingProdID = array_column($updatedCartArray, 'prodID');
                          $index = array_search($cart->prodID, $existingProdID);

                          if ($index !== false) {
                              $updatedCartArray[$index]->quantity++;
                              $updatedCartArray[$index]->totalCost += $cart->cost;
                          } else {
                              $updatedCartArray[] = $cart;
                          }
                      }

                      // Display the updated cart items
                      foreach ($updatedCartArray as $cart) {
                          $cart->displayShoppingBox();
                      }

                  echo '</ul>
                </div>
              </div>
            </div>

            <!-- Payment and Delivery Options -->
            <div class="border-t border-gray-200 px-4 py-6 sm:px-6">
              <div class="mb-4">
                  <h3 class="text-lg font-medium text-gray-900">Payment Options</h3>
                  <select id="payment-options" class="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md">
                      <option>Credit/Debit Card</option>
                      <option>Gcash</option>
                      <option>Bank Transfer</option>
                      <option>Cash on Delivery (COD)</option>
                  </select>
              </div>

              <div class="mb-4">
                  <h3 class="text-lg font-medium text-gray-900">Delivery Options</h3>
                  <select id="delivery-options" class="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md">
                      <option>Standard Shipping</option>
                      <option>Express Shipping</option>
                      <option>Store Pickup</option>
                      <option>Same-Day Delivery</option>
                  </select>
              </div>';

              $total = 0;
              foreach ($updatedCartArray as $cart) {
                  $total += $cart->totalCost;
              }

            echo '<div class="flex justify-between text-base font-medium text-gray-900">
                    <p>Subtotal</p>
                    <p>₱' . $total . '</p>
              </div>
              <p class="mt-0.5 text-sm text-gray-500">Shipping and taxes calculated at checkout.</p>
              <div class="mt-6">
                <button onclick="handleCheckout()" class="flex items-center justify-center rounded-md border border-transparent bg-indigo-600 px-6 py-3 text-base font-medium text-white shadow-sm hover:bg-indigo-700">Checkout</button>
              </div>
              <div class="mt-6 flex justify-center text-center text-sm text-gray-500">
                <p>
                  or
                  <button type="button" class="font-medium text-indigo-600 hover:text-indigo-500" onclick="toggleShoppingCart()">
                    Continue Shopping
                    <span aria-hidden="true"> &rarr;</span>
                  </button>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  </div>
  '
  ;?>

<script>
  function toggleShoppingCart() {
    const shoppingCartSidebar = document.getElementById('shoppingCartSidebar');
    shoppingCartSidebar.classList.toggle('hidden');
  }
</script>

</body>
</html>


