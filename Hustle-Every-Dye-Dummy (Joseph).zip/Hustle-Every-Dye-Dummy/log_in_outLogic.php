<?php

if ($_SERVER["REQUEST_METHOD"] === "POST") { 

  require_once "dbConnector.php";
  require_once "sessionConfig.php";
  require_once "dbQueries.php";

  $userName = $_POST["userName"];
  $password = $_POST["password"];
  $email = $_POST["email"];

  $errors = ErrorCheckLogin($connect, $userName, $password, $email);

  if ($errors) {
    $_SESSION['errorsLogin'] = $errors;
    header("Location: login.php");
    mysqli_close($connect);
    die();
  }

  $accID = GetAccountID($connect, $userName)["accID"];
  $newSessionId = session_create_id();
  $sessionId = $newSessionId . "_" . $userID;
  session_id($sessionId);

  $_SESSION["accID"] = $accID;
  $_SESSION["regenLast"] = time();

  header("Location: index.php");
  mysqli_close($connect);
  die();

} else if ($_SERVER["REQUEST_METHOD"] !== "POST" AND isset($_GET['logout'])) {

  session_start();
  session_unset();
  session_destroy();
  header("Location: index.php");
  mysqli_close($connect);
  die();

} else {

  header("Location: login.php");
  mysqli_close($connect);
  die();

}

function ErrorCheckLogin($connect, string $userName, string $password, string $email) {
  $errors = [];

  if (empty($userName) OR empty($password) OR empty($email)) {
        $errors["emptyFields"] = "Fill out all the Fields!";
    } else {

      if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
          $errors["invalidEmail"] = "Enter a valid Email!";
      }

      if (GetUsername($connect, $userName)["userName"] != $userName) {
          $errors["inccorrectUsername"] = "Incorrect Username Entered!";

      } else {

        if (GetEmailLogin($connect, $userName)["email"] != $email) {
            $errors["incorrectEmail"] = "Incorrect Email Entered!";
        }

        if ($password != GetPassword($connect, $userName)["password"]) {
            $errors["incorrectPassword"] = "Incorrect Password Entered!";
        }
      }
    }
  return $errors;
}